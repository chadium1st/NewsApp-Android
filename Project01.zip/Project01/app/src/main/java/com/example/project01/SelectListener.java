package com.example.project01;

import com.example.project01.Models.NewsHeadlines;

public interface SelectListener {
    void onNewsClicked(NewsHeadlines headlines);
}
